# Alarm System

## 1. Introduction

In here there are 3 classes.

## 2. Usage

Initialize a new `CameraSet`. We represent the initial states
as a 2D array of int, and screenshot from there.

## 3. Message to future maintainer

This is a call for help. I cannot save this project.

All the test cases given by the QA are failing. 
The code left by an intern is a mess. Sometimes
there are errors popping everywhere when the QA enter
some random inputs.

Hence, what I believe the QA team is looking for is:
- A list of fixed bugs, which should be shown on the 
commit history. A document is fine, but the QAs are
demanding.
- A better test cases. The QAs like theirs, but they are too
lazy to go for more coverage.
- List of changes, but it should not be needed if the commit 
history is well-documented.
- Maybe better documentation along the way. The first
guy really want to make this codebase a hell on earth.

Really hope the best for you, future maintainer.